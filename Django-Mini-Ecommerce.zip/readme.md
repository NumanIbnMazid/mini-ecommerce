# Add Order:

    {
        "orderItems": [
            {
                "product": 2,
                "qty": 4
            }
        ],
        "shippingAddress": {
            "address": "Dhaka",
            "city": "Dhaka",
            "postalCode": "1200",
            "country": "Bangladesh"
        }
    }